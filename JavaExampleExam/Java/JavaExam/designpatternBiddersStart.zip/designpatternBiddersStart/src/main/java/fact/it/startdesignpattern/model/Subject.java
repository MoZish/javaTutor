package fact.it.startdesignpattern.model;

public abstract class Subject {
    public void attachObserver(Bidder b){

    }
    public void detachObserver(Bidder b){

    }
    public void notifyObservers(){

    }
}
