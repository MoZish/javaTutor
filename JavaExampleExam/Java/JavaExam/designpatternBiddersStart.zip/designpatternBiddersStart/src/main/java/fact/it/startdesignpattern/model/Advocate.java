package fact.it.startdesignpattern.model;

public class Advocate{

    public void informClient(){
    }
}
