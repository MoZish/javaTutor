package fact.it.startdesignpattern.model;

public abstract class Profession  {

    public Profession() {
    }

}
